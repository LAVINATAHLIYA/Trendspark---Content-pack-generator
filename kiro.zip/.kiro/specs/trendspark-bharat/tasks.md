# Implementation Plan

## Current Status
No implementation exists yet. All tasks below need to be completed from scratch.

- [x] 1. Set up project structure and dependencies


  - Create TypeScript/Node.js project with necessary configuration files (package.json, tsconfig.json)
  - Install dependencies: OpenAI SDK or Anthropic SDK, fast-check for property testing, vitest or jest for testing
  - Set up build and development scripts
  - Create basic folder structure: src/, src/types/, src/validation/, src/ai/, src/api/, src/ui/
  - _Requirements: All_

- [ ] 2. Implement core data models and types
  - [x] 2.1 Create TypeScript interfaces and types


    - Define Language, Vibe, and Platform types
    - Create ContentPackRequest interface
    - Create Caption interface with style, text, and wordCount fields
    - Create TrendingStyle interface
    - Create ContentPack interface with captions, hashtags, postIdeas, reelScript, and trendingStyles
    - Create TrendsResponse interface
    - _Requirements: 1.1, 1.2, 1.3_
  
  - [ ]* 2.2 Write property test for complete content pack generation
    - **Property 1: Complete content pack generation**
    - **Validates: Requirements 1.1**
    - Verify all required fields are present in generated content packs

- [ ] 3. Implement input validation logic
  - [x] 3.1 Create validation functions for ContentPackRequest


    - Validate topic is non-empty string (trim whitespace)
    - Validate at least one language is selected
    - Validate at least one vibe is selected
    - Validate platform is selected
    - Validate language values are from supported list
    - Validate vibe values are from supported list
    - Return descriptive error messages for each validation failure
    - _Requirements: 1.1, 1.2, 1.3_
  
  - [ ]* 3.2 Write unit tests for input validation
    - Test empty topic rejection
    - Test whitespace-only topic rejection
    - Test empty language array rejection
    - Test unsupported language rejection
    - Test empty vibe array rejection
    - Test unsupported vibe rejection
    - Test missing platform rejection
    - Test valid inputs pass validation
    - _Requirements: 1.1, 1.2, 1.3_

- [ ] 4. Implement AI prompt engine
  - [x] 4.1 Create prompt template constructor


    - Build dynamic prompt based on topic, languages, vibes, platform, and includeScript
    - Include explicit constraints: 3 captions per language, 20 word limit for Reels/Shorts, 10 hashtags, 5-8 post ideas
    - Add cultural context instructions for each language
    - Add variance instructions to avoid repetition
    - Specify JSON output format with exact field names
    - Include instructions for trending styles (5-7 items, format descriptions only)
    - Handle script generation logic (includeScript OR storytelling vibe)
    - _Requirements: 1.1, 1.5, 2.1, 2.2, 2.3, 2.4, 2.5, 3.1, 3.2, 3.3, 4.1, 4.2, 4.3, 4.4, 5.1, 5.2, 5.3, 5.4, 6.1, 6.2, 7.1, 7.2, 7.3, 7.4_
  
  - [x] 4.2 Implement AI model integration


    - Set up API client for OpenAI (GPT-4/GPT-3.5-turbo) or Anthropic (Claude)
    - Configure max_tokens to 1500
    - Configure 30-second timeout
    - Implement error handling for API failures, timeouts, and rate limits
    - Add retry logic for transient failures
    - _Requirements: 1.1, 9.1, 9.2, 9.3_
  
  - [x] 4.3 Create response parser


    - Parse AI JSON response into ContentPack structure
    - Validate response has all required fields
    - Handle incomplete or malformed responses gracefully
    - Implement single retry for incomplete responses
    - Add word count calculation for captions
    - _Requirements: 1.1, 8.1_
  
  - [ ]* 4.4 Write property test for multi-language output structure
    - **Property 2: Multi-language output structure**
    - **Validates: Requirements 1.2, 3.4, 8.3**
    - Verify output contains blocks for exactly the selected languages
  
  - [ ]* 4.5 Write property test for three distinct caption styles
    - **Property 3: Three distinct caption styles**
    - **Validates: Requirements 2.1**
    - Verify exactly 3 captions per language with correct styles
  
  - [ ]* 4.6 Write property test for caption word count limit
    - **Property 4: Caption word count limit**
    - **Validates: Requirements 2.2**
    - Verify all captions ≤20 words for Reels/Shorts platforms
  
  - [ ]* 4.7 Write property test for caption variance
    - **Property 5: Caption variance**
    - **Validates: Requirements 2.4**
    - Verify captions are sufficiently different (no identical captions)
  
  - [ ]* 4.8 Write property test for exactly ten hashtags
    - **Property 6: Exactly ten hashtags**
    - **Validates: Requirements 3.1**
    - Verify exactly 10 hashtags per selected language
  
  - [ ]* 4.9 Write property test for post ideas count range
    - **Property 7: Post ideas count range**
    - **Validates: Requirements 4.1**
    - Verify 5-8 post ideas generated
  
  - [ ]* 4.10 Write property test for post ideas line limit
    - **Property 8: Post ideas line limit**
    - **Validates: Requirements 4.2**
    - Verify each post idea ≤2 lines
  
  - [ ]* 4.11 Write property test for script generation rules
    - **Property 9: Script generation rules**
    - **Validates: Requirements 5.1, 5.2, 5.3**
    - Verify script generated if includeScript=true OR storytelling vibe selected
  
  - [ ]* 4.12 Write property test for script quote wrapping
    - **Property 10: Script quote wrapping**
    - **Validates: Requirements 5.4**
    - Verify script text wrapped in quotes when present
  
  - [ ]* 4.13 Write property test for trending styles count range
    - **Property 11: Trending styles count range**
    - **Validates: Requirements 6.1**
    - Verify 5-7 trending styles included
  
  - [ ]* 4.14 Write property test for no repeated phrases
    - **Property 12: No repeated phrases**
    - **Validates: Requirements 7.3**
    - Verify no 4+ word phrases repeated across outputs
  
  - [ ]* 4.15 Write property test for valid JSON output
    - **Property 13: Valid JSON output**
    - **Validates: Requirements 8.1**
    - Verify output is valid, parseable JSON
  
  - [ ]* 4.16 Write property test for human-readable section presence
    - **Property 14: Human-readable section presence**
    - **Validates: Requirements 8.2**
    - Verify human-readable section field is non-empty

- [ ] 5. Checkpoint - Verify core generation logic
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 6. Implement content generation API endpoint
  - [x] 6.1 Create POST /api/generate endpoint


    - Set up Express or similar web framework
    - Accept ContentPackRequest in request body
    - Call validation functions and return 400 errors for failures
    - Invoke AI prompt engine
    - Return ContentPack response as JSON
    - Add request logging
    - _Requirements: 1.1, 1.5, 8.1, 8.2, 9.1_
  
  - [x] 6.2 Implement comprehensive error handling

    - Return 400 errors for validation failures with descriptive messages
    - Return 504 errors for AI model timeouts
    - Return 500 errors for generation failures
    - Return 429 errors for rate limiting
    - Include error details in response body
    - _Requirements: 1.1_
  
  - [ ]* 6.3 Write integration test for content generation endpoint
    - Test complete request-response flow with valid input
    - Test validation error responses (400)
    - Test timeout handling (504)
    - Test rate limiting (429)
    - _Requirements: 1.1, 8.1_

- [ ] 7. Implement trends API endpoint
  - [x] 7.1 Create trending styles data source


    - Create static data file with 10-15 trending styles for Indian market
    - Include style name and format description (no copyrighted audio names)
    - Examples: "split-screen reaction", "day-in-life montage", "before/after transformation"
    - Ensure cultural relevance to Indian social media
    - _Requirements: 6.1, 6.2, 6.3, 10.2, 10.3_
  
  - [x] 7.2 Create GET /api/trends/today endpoint


    - Return random selection of 5-7 trending styles from data source
    - Include lastUpdated timestamp
    - Implement in-memory caching (1 hour TTL)
    - Return TrendsResponse JSON structure
    - _Requirements: 10.1, 10.2, 10.3_
  
  - [ ]* 7.3 Write property test for trends endpoint count range
    - **Property 15: Trends endpoint count range**
    - **Validates: Requirements 10.1**
    - Verify response contains 5-7 trending styles
  
  - [ ]* 7.4 Write integration test for trends endpoint
    - Test GET request and response structure
    - Test caching behavior (same results within 1 hour)
    - Test response format matches TrendsResponse interface
    - _Requirements: 10.1, 10.2, 10.3_

- [ ] 8. Implement rate limiting and performance optimizations
  - [x] 8.1 Add rate limiting middleware


    - Use express-rate-limit or similar library
    - Limit to 10 requests per minute per IP address
    - Return 429 error with Retry-After header when exceeded
    - _Requirements: 9.1_
  
  - [x] 8.2 Verify caching implementation

    - Confirm trends endpoint caching works correctly
    - Test cache expiration after 1 hour
    - _Requirements: 9.1, 10.1_

- [ ] 9. Implement front-end interface
  - [x] 9.1 Create input form component


    - Add text input for topic with placeholder
    - Add multi-select dropdown for languages (8 options: Hindi, Hinglish, Gujarati, Marathi, Tamil, Telugu, Bengali, English)
    - Add multi-select dropdown for vibes (8 options: aesthetic, emotional, romantic, funny/relatable, short+punchy, storytelling, desi/hinglish, inspirational)
    - Add single-select dropdown for platform (Instagram Reels, YouTube Shorts, Instagram Posts)
    - Add toggle switch for includeScript
    - Implement form validation before submission
    - Add loading state during generation
    - _Requirements: 1.1, 1.2, 1.3_
  
  - [x] 9.2 Create content pack display component

    - Display captions organized by language with clear labels
    - Display hashtags organized by language with clear labels
    - Display post ideas as numbered list
    - Display reel script in quotes (if present)
    - Display trending styles as list
    - Show both JSON view and human-readable formatted view
    - Add tab or toggle to switch between views
    - Ensure UTF-8 encoding for all text display
    - _Requirements: 8.1, 8.2, 8.3, 1.2, 2.3, 2.5_
  
  - [x] 9.3 Implement action buttons

    - Add "Regenerate" button that calls API with same parameters
    - Add "Copy Pack" button that copies formatted content to clipboard
    - Show success feedback after copy
    - Disable buttons during loading state
    - _Requirements: 8.4_
  
  - [x] 9.4 Implement clarifying question flow

    - Add logic to detect ambiguous topics (optional - can be simple heuristic)
    - Display clarifying question prompt when detected
    - Allow user to refine topic before generation
    - Resubmit with refined topic
    - _Requirements: 1.4, 1.5_
  
  - [x] 9.5 Add web font support for Indian scripts


    - Include Google Fonts or similar for Devanagari, Tamil, Telugu, Bengali scripts
    - Configure font-family CSS for proper rendering
    - Test display of all 8 supported languages
    - _Requirements: 1.2, 2.3_
  
  - [ ]* 9.6 Write integration test for complete UI flow
    - Test form submission with valid inputs
    - Test content display after generation
    - Test regenerate functionality
    - Test copy to clipboard functionality
    - Test error display for validation failures
    - _Requirements: 1.1, 8.4_

- [ ] 10. Final checkpoint - Ensure all tests pass
  - Run all unit tests, property tests, and integration tests
  - Verify all 15 correctness properties are validated
  - Test end-to-end flow manually if needed
  - Ensure all tests pass, ask the user if questions arise.
