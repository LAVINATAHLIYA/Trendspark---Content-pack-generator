# Design Document

## Overview

TrendSpark Bharat is a lightweight AI-powered micro-application that generates culturally relevant content packs for Indian creators. The system consists of a minimal front-end interface built as a Kiro micro-tool and an AI prompt engine that produces captions, hashtags, post ideas, reel scripts, and trending topic styles across eight Indian languages.

The architecture prioritizes speed, simplicity, and cultural relevance. The system uses a single AI model call per request to minimize latency, with carefully crafted prompts that ensure outputs match the creator's selected languages, vibes, and platform requirements.

## Architecture

### System Components

The system follows a simple request-response architecture:

1. **Front-end Interface (Kiro Micro-tool)**
   - Single-page input form with multi-select controls
   - Auto-submit on input completion
   - Display area for generated content packs
   - Copy and regenerate action buttons

2. **AI Prompt Engine**
   - Core content generation logic
   - Language and vibe adaptation
   - Output formatting and structuring
   - Trend style generation

3. **Optional Backend Service**
   - Lightweight Flask or serverless function
   - Analytics tracking (optional)
   - Trends API endpoint
   - Rate limiting and caching

### Data Flow

```
Creator Input → Validation → AI Prompt Construction → AI Model Call → 
Response Parsing → Format Output → Display to Creator
```

For the trends endpoint:
```
API Request → Retrieve Current Trends → Format Response → Return JSON
```

## Components and Interfaces

### 1. Input Interface

**Component:** Form with multi-select and toggle controls

**Inputs:**
- `topic`: String (required) - The content topic
- `languages`: Array of strings (required) - Selected from: Hindi, Hinglish, Gujarati, Marathi, Tamil, Telugu, Bengali, English
- `vibes`: Array of strings (required) - Selected from: aesthetic, emotional, romantic, funny/relatable, short+punchy, storytelling, desi/hinglish, inspirational
- `platform`: String (required) - Selected from: Instagram Reels, YouTube Shorts, Instagram Posts, etc.
- `includeScript`: Boolean (default: false) - Toggle for reel script generation

**Validation Rules:**
- Topic must be non-empty string
- At least one language must be selected
- At least one vibe must be selected
- Platform must be selected

### 2. AI Prompt Engine

**Component:** Prompt constructor and response parser

**Core Prompt Template:**
```
You are TrendSpark Bharat, an AI assistant that produces compact, platform-ready 
content packs for Indian creators.

Topic: {topic}
Languages: {languages}
Vibes: {vibes}
Platform: {platform}
Include Script: {includeScript}

Generate a content pack with:
1. Three caption options (distinct styles: short-aesthetic, emotional/storytelling, funny/desi)
   - Each ≤20 words for Reels/Shorts
   - Use culturally relevant idioms
2. Ten optimized hashtags (mix high-reach + niche)
3. Five to eight post ideas (1-2 lines each, mix of low and high effort)
4. {if includeScript or storytelling vibe} One 5-7 second reel script in quotes
5. Five to seven trending topic styles (format descriptions, no copyrighted audio)

Format as JSON with human-readable sections.
```

**Response Structure:**
```json
{
  "captions": {
    "language1": [
      {"style": "short-aesthetic", "text": "..."},
      {"style": "emotional", "text": "..."},
      {"style": "funny-desi", "text": "..."}
    ],
    "language2": [...]
  },
  "hashtags": {
    "language1": ["#tag1", "#tag2", ...],
    "language2": [...]
  },
  "postIdeas": [
    "Idea 1 (low-effort)",
    "Idea 2 (high-effort)",
    ...
  ],
  "reelScript": "Script text in quotes" | null,
  "trendingStyles": [
    "Style 1 description",
    "Style 2 description",
    ...
  ]
}
```

### 3. Trends API Endpoint

**Endpoint:** `/api/trends/today`

**Method:** GET

**Response:**
```json
{
  "trends": [
    {
      "style": "split-screen reaction",
      "description": "Show before/after or two perspectives side by side"
    },
    {
      "style": "day-in-life montage",
      "description": "Quick cuts showing daily routine moments"
    },
    ...
  ],
  "lastUpdated": "2025-11-29T10:00:00Z"
}
```

### 4. Content Generation API Endpoint

**Endpoint:** `/api/generate`

**Method:** POST

**Request Body:**
```json
{
  "topic": "morning routine",
  "language": ["Hindi", "Hinglish"],
  "vibe": ["aesthetic", "short+punchy"],
  "platform": "Instagram Reels",
  "includeScript": true
}
```

**Response:** Same structure as AI Prompt Engine response

## Data Models

### ContentPackRequest

```typescript
interface ContentPackRequest {
  topic: string;
  language: Language[];
  vibe: Vibe[];
  platform: Platform;
  includeScript: boolean;
}

type Language = 'Hindi' | 'Hinglish' | 'Gujarati' | 'Marathi' | 
                'Tamil' | 'Telugu' | 'Bengali' | 'English';

type Vibe = 'aesthetic' | 'emotional' | 'romantic' | 'funny/relatable' | 
            'short+punchy' | 'storytelling' | 'desi/hinglish' | 'inspirational';

type Platform = 'Instagram Reels' | 'YouTube Shorts' | 'Instagram Posts';
```

### ContentPack

```typescript
interface ContentPack {
  captions: Record<Language, Caption[]>;
  hashtags: Record<Language, string[]>;
  postIdeas: string[];
  reelScript: string | null;
  trendingStyles: TrendingStyle[];
}

interface Caption {
  style: 'short-aesthetic' | 'emotional' | 'funny-desi';
  text: string;
  wordCount: number;
}

interface TrendingStyle {
  style: string;
  description: string;
}
```

### TrendsResponse

```typescript
interface TrendsResponse {
  trends: TrendingStyle[];
  lastUpdated: string;
}
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Complete content pack generation
*For any* valid content pack request (with topic, languages, vibes, platform), the system should generate a content pack containing all required fields: captions for each language, hashtags for each language, post ideas, trending styles, and optionally a reel script.
**Validates: Requirements 1.1**

### Property 2: Multi-language output structure
*For any* set of selected languages, the output should contain caption blocks and hashtag blocks for exactly those languages, with each language clearly labeled.
**Validates: Requirements 1.2, 3.4, 8.3**

### Property 3: Three distinct caption styles
*For any* content pack request, the system should generate exactly three captions per language with the three distinct styles: short-aesthetic, emotional/storytelling, and funny-desi.
**Validates: Requirements 2.1**

### Property 4: Caption word count limit
*For any* content pack request where the platform is Instagram Reels or YouTube Shorts, all generated captions should contain 20 words or fewer.
**Validates: Requirements 2.2**

### Property 5: Caption variance
*For any* content pack request, the three generated captions for each language should be sufficiently different from each other (no identical captions, and similarity below a threshold).
**Validates: Requirements 2.4**

### Property 6: Exactly ten hashtags
*For any* content pack request, the system should generate exactly ten hashtags per selected language.
**Validates: Requirements 3.1**

### Property 7: Post ideas count range
*For any* content pack request, the system should generate between five and eight post ideas (inclusive).
**Validates: Requirements 4.1**

### Property 8: Post ideas line limit
*For any* generated post idea, the text should contain at most two lines (one or two newline characters maximum).
**Validates: Requirements 4.2**

### Property 9: Script generation rules
*For any* content pack request, a reel script should be generated if and only if either includeScript is true OR storytelling vibe is selected; otherwise the script field should be null.
**Validates: Requirements 5.1, 5.2, 5.3**

### Property 10: Script quote wrapping
*For any* generated reel script (when not null), the script text should be wrapped in quotes (start and end with quotation marks).
**Validates: Requirements 5.4**

### Property 11: Trending styles count range
*For any* content pack request, the system should include between five and seven trending topic styles (inclusive).
**Validates: Requirements 6.1**

### Property 12: No repeated phrases
*For any* content pack, no phrase (sequence of 4+ words) should appear more than once across all text outputs (captions, hashtags, post ideas, script, trending styles).
**Validates: Requirements 7.3**

### Property 13: Valid JSON output
*For any* content pack request, the system should return output that is valid, parseable JSON.
**Validates: Requirements 8.1**

### Property 14: Human-readable section presence
*For any* content pack response, the output should include a human-readable section field that is non-empty.
**Validates: Requirements 8.2**

### Property 15: Trends endpoint count range
*For any* request to the /api/trends/today endpoint, the response should contain between five and seven trending styles (inclusive).
**Validates: Requirements 10.1**

## Error Handling

### Input Validation Errors

**Invalid Topic:**
- Empty or whitespace-only topic strings should return a 400 error with message: "Topic is required"

**Invalid Language Selection:**
- Empty language array should return a 400 error with message: "At least one language must be selected"
- Unsupported language values should return a 400 error with message: "Unsupported language: {language}"

**Invalid Vibe Selection:**
- Empty vibe array should return a 400 error with message: "At least one vibe must be selected"
- Unsupported vibe values should return a 400 error with message: "Unsupported vibe: {vibe}"

**Invalid Platform:**
- Missing or unsupported platform should return a 400 error with message: "Valid platform is required"

### AI Generation Errors

**Model Timeout:**
- If AI model call exceeds 30 seconds, return a 504 error with message: "Content generation timed out. Please try again."

**Model Response Parsing Error:**
- If AI response cannot be parsed into expected structure, return a 500 error with message: "Failed to generate content pack. Please try again."

**Incomplete Response:**
- If AI response is missing required fields, attempt to regenerate once
- If second attempt fails, return a 500 error with message: "Failed to generate complete content pack"

### Rate Limiting

**Too Many Requests:**
- If user exceeds rate limit (e.g., 10 requests per minute), return a 429 error with message: "Rate limit exceeded. Please wait before making another request."

### Trends Endpoint Errors

**Trends Data Unavailable:**
- If trends data cannot be retrieved, return a 503 error with message: "Trends data temporarily unavailable"

## Testing Strategy

### Unit Testing Approach

Unit tests will verify specific examples and edge cases:

**Input Validation Tests:**
- Test empty topic rejection
- Test empty language array rejection
- Test unsupported language rejection
- Test empty vibe array rejection
- Test unsupported vibe rejection
- Test missing platform rejection

**Output Structure Tests:**
- Test single language output structure
- Test multiple language output structure
- Test script generation with includeScript=true
- Test script generation with storytelling vibe
- Test no script generation when both are false

**Edge Cases:**
- Test maximum language selection (all 8 languages)
- Test maximum vibe selection (all 8 vibes)
- Test ambiguous topic handling
- Test very long topic strings
- Test special characters in topics

### Property-Based Testing Approach

Property-based tests will verify universal properties across many randomly generated inputs. We will use **fast-check** (for TypeScript/JavaScript) as the property-based testing library.

**Configuration:**
- Each property-based test should run a minimum of 100 iterations
- Each test must be tagged with a comment referencing the correctness property from this design document
- Tag format: `// Feature: trendspark-bharat, Property {number}: {property_text}`
- Each correctness property must be implemented by a SINGLE property-based test

**Test Generators:**

We will create generators for:
- Valid topics (random strings, 5-50 characters)
- Language arrays (random subsets of supported languages, 1-8 items)
- Vibe arrays (random subsets of supported vibes, 1-8 items)
- Platform values (random selection from supported platforms)
- includeScript boolean (random true/false)

**Property Tests to Implement:**

1. **Property 1 Test:** Generate random valid requests, verify all required fields present
2. **Property 2 Test:** Generate random language selections, verify output has blocks for exactly those languages
3. **Property 3 Test:** Generate random requests, verify exactly 3 captions per language with correct styles
4. **Property 4 Test:** Generate random requests with Reels/Shorts platform, verify all captions ≤20 words
5. **Property 5 Test:** Generate random requests, verify captions are sufficiently different
6. **Property 6 Test:** Generate random requests, verify exactly 10 hashtags per language
7. **Property 7 Test:** Generate random requests, verify 5-8 post ideas
8. **Property 8 Test:** Generate random requests, verify each post idea ≤2 lines
9. **Property 9 Test:** Generate random requests, verify script presence matches rules
10. **Property 10 Test:** Generate random requests with script, verify quote wrapping
11. **Property 11 Test:** Generate random requests, verify 5-7 trending styles
12. **Property 12 Test:** Generate random requests, verify no repeated phrases
13. **Property 13 Test:** Generate random requests, verify valid JSON output
14. **Property 14 Test:** Generate random requests, verify human-readable section present
15. **Property 15 Test:** Call trends endpoint multiple times, verify 5-7 styles

**Integration Testing:**

- End-to-end test: Submit request through UI, verify complete flow
- API endpoint test: POST to /api/generate, verify response structure
- Trends endpoint test: GET /api/trends/today, verify response structure
- Multi-language test: Request with all 8 languages, verify all outputs present
- Regenerate test: Generate pack, click regenerate, verify new pack is different

### Test Coverage Goals

- Unit tests: Cover all input validation and error cases
- Property tests: Cover all 15 correctness properties
- Integration tests: Cover complete user workflows
- Target: 90%+ code coverage for core generation logic

## Implementation Notes

### AI Model Selection

Recommended models for content generation:
- GPT-4 or GPT-3.5-turbo for high-quality, culturally aware content
- Claude 3 for nuanced language understanding
- Gemini Pro for multilingual support

### Prompt Engineering Best Practices

1. **Explicit Constraints:** Clearly state word limits, count requirements, and format expectations
2. **Cultural Context:** Include examples of culturally relevant idioms for each language
3. **Output Format:** Specify JSON structure with exact field names
4. **Variance Instructions:** Explicitly request diverse outputs to avoid repetition
5. **Few-Shot Examples:** Include 1-2 example outputs for each language/vibe combination

### Performance Optimization

1. **Caching:** Cache trending styles for 1 hour to reduce API calls
2. **Token Limits:** Set max_tokens to 1500 to ensure concise outputs
3. **Streaming:** Consider streaming responses for faster perceived performance
4. **Parallel Processing:** If multiple language blocks are large, consider parallel generation

### Localization Considerations

1. **Script Support:** Ensure UI supports Devanagari, Tamil, Telugu, Bengali scripts
2. **RTL Support:** Not required for current language set
3. **Font Loading:** Include web fonts for Indian language scripts
4. **Character Encoding:** Use UTF-8 throughout

### Future Enhancements

1. **Trend Tracking:** Implement automated trend detection from social media APIs
2. **User Feedback:** Add thumbs up/down for content quality improvement
3. **History:** Save generated packs for user reference
4. **Templates:** Allow users to save favorite vibe/language combinations
5. **Analytics:** Track which vibes and languages are most popular
6. **A/B Testing:** Test different prompt variations for quality improvement
