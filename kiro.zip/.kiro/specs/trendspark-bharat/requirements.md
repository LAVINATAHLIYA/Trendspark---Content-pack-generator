# Requirements Document

## Introduction

TrendSpark Bharat is an AI-powered content pack generator designed specifically for Indian micro-creators. The system generates platform-ready content including captions, hashtags, post ideas, reel scripts, and trending topic styles across multiple Indian languages. It targets lifestyle creators, daily vloggers, and general micro-creators who need quick, culturally relevant content that resonates with Indian audiences.

## Glossary

- **TrendSpark System**: The complete AI content pack generator application
- **Content Pack**: A bundled output containing captions, hashtags, post ideas, optional reel script, and trending styles
- **Creator**: The end user who generates content packs for social media platforms
- **Vibe**: A content tone or style category (e.g., aesthetic, emotional, funny/relatable)
- **Hinglish**: A blend of Hindi and English commonly used in Indian social media
- **Reel Script**: A short 5-7 second video script for Instagram Reels or YouTube Shorts
- **Trending Topic Style**: A description of popular content formats without copyrighted audio names
- **Platform**: Target social media platform (Instagram Reels, YouTube Shorts, etc.)

## Requirements

### Requirement 1

**User Story:** As a creator, I want to input my content topic and preferences, so that I can receive a customized content pack quickly.

#### Acceptance Criteria

1. WHEN a creator submits a topic with language selections, vibe selections, platform choice, and script toggle, THEN the TrendSpark System SHALL generate a complete content pack
2. WHEN a creator selects multiple languages from the supported list (Hindi, Hinglish, Gujarati, Marathi, Tamil, Telugu, Bengali, English), THEN the TrendSpark System SHALL provide captions and hashtags for each selected language in separate labeled blocks
3. WHEN a creator selects multiple vibes from the supported list (aesthetic, emotional, romantic, funny/relatable, short+punchy, storytelling, desi/hinglish, inspirational), THEN the TrendSpark System SHALL incorporate all selected vibes into the content pack
4. WHEN a creator provides an ambiguous topic, THEN the TrendSpark System SHALL ask one clarifying question before generating the pack
5. WHEN a creator submits a clear topic, THEN the TrendSpark System SHALL generate the full pack immediately without additional confirmations

### Requirement 2

**User Story:** As a creator, I want to receive three distinct caption options, so that I can choose the style that best fits my content.

#### Acceptance Criteria

1. WHEN the TrendSpark System generates captions, THEN the TrendSpark System SHALL produce exactly three caption options with distinct styles (short-aesthetic, emotional/storytelling, funny/desi)
2. WHEN generating captions for Instagram Reels or YouTube Shorts, THEN the TrendSpark System SHALL limit each caption to 20 words or fewer
3. WHEN the creator selects specific languages, THEN the TrendSpark System SHALL use culturally relevant idioms and language-appropriate expressions in the captions
4. WHEN generating multiple captions, THEN the TrendSpark System SHALL ensure high variance between caption options to avoid repetition
5. WHEN Hinglish is selected as a language, THEN the TrendSpark System SHALL blend Hindi and English naturally in the captions

### Requirement 3

**User Story:** As a creator, I want to receive optimized hashtags, so that I can maximize my content reach on social media.

#### Acceptance Criteria

1. WHEN the TrendSpark System generates hashtags, THEN the TrendSpark System SHALL produce exactly ten hashtags
2. WHEN generating hashtags, THEN the TrendSpark System SHALL include a mix of high-reach hashtags and niche hashtags
3. WHEN the creator selects specific languages, THEN the TrendSpark System SHALL prepend language-appropriate hashtags where possible
4. WHEN multiple languages are selected, THEN the TrendSpark System SHALL provide hashtag sets for each selected language in separate labeled blocks

### Requirement 4

**User Story:** As a creator, I want to receive multiple post ideas, so that I can plan my content calendar efficiently.

#### Acceptance Criteria

1. WHEN the TrendSpark System generates post ideas, THEN the TrendSpark System SHALL produce between five and eight post ideas
2. WHEN generating post ideas, THEN the TrendSpark System SHALL limit each idea to one or two lines for clarity
3. WHEN generating post ideas, THEN the TrendSpark System SHALL include at least two low-effort ideas and at least two higher-effort ideas
4. WHEN generating post ideas, THEN the TrendSpark System SHALL ensure all ideas are clear and executable

### Requirement 5

**User Story:** As a creator, I want to optionally receive a short reel script, so that I can quickly produce video content.

#### Acceptance Criteria

1. WHEN a creator enables the includeScript toggle, THEN the TrendSpark System SHALL generate one short reel script of 5-7 seconds duration
2. WHEN a creator selects the storytelling vibe, THEN the TrendSpark System SHALL generate one short reel script regardless of the toggle state
3. WHEN a creator disables the includeScript toggle and does not select storytelling vibe, THEN the TrendSpark System SHALL not generate a reel script
4. WHEN the TrendSpark System generates a reel script, THEN the TrendSpark System SHALL wrap the script in quotes for clear identification

### Requirement 6

**User Story:** As a creator, I want to know current trending topic styles in India, so that I can create content that aligns with popular formats.

#### Acceptance Criteria

1. WHEN the TrendSpark System generates a content pack, THEN the TrendSpark System SHALL include between five and seven trending topic styles
2. WHEN describing trending topic styles, THEN the TrendSpark System SHALL use format descriptions (e.g., "split-screen reaction", "before/after transformation") instead of copyrighted audio names
3. WHEN listing trending styles, THEN the TrendSpark System SHALL ensure all styles are currently relevant to Indian social media trends

### Requirement 7

**User Story:** As a creator, I want content that matches my selected tone and cultural context, so that my audience finds it relatable and engaging.

#### Acceptance Criteria

1. WHEN the TrendSpark System generates content, THEN the TrendSpark System SHALL match the language, tone, and idioms to the selected languages and vibes
2. WHEN generating content, THEN the TrendSpark System SHALL use short, scroll-stopping, and culturally relevant tone
3. WHEN generating content across multiple outputs, THEN the TrendSpark System SHALL avoid repeated phrases within the same content pack
4. WHEN the creator selects desi or Hinglish vibes, THEN the TrendSpark System SHALL incorporate culturally specific Indian expressions and references

### Requirement 8

**User Story:** As a creator, I want to receive outputs in a structured format, so that I can easily copy and use the content.

#### Acceptance Criteria

1. WHEN the TrendSpark System generates a content pack, THEN the TrendSpark System SHALL return outputs in JSON-friendly text blocks
2. WHEN the TrendSpark System generates a content pack, THEN the TrendSpark System SHALL also provide a human-readable section for easy review
3. WHEN multiple languages are selected, THEN the TrendSpark System SHALL organize captions and hashtags in separate labeled blocks per language
4. WHEN the TrendSpark System completes generation, THEN the TrendSpark System SHALL display the content pack with "Regenerate" and "Copy Pack" action options

### Requirement 9

**User Story:** As a creator, I want the system to respond quickly, so that I can generate content packs without delays.

#### Acceptance Criteria

1. WHEN a creator submits a content pack request, THEN the TrendSpark System SHALL generate outputs with minimal latency
2. WHEN generating outputs, THEN the TrendSpark System SHALL limit AI model tokens to essential output only
3. WHEN generating outputs, THEN the TrendSpark System SHALL use concise phrasing to maintain low response times

### Requirement 10

**User Story:** As a creator, I want to access trending topics for today, so that I can create timely and relevant content.

#### Acceptance Criteria

1. WHEN a creator requests today's trends via the trends endpoint, THEN the TrendSpark System SHALL return a list of five to seven trending styles
2. WHEN returning trending styles, THEN the TrendSpark System SHALL exclude copyrighted audio names and use format descriptions instead
3. WHEN the trends endpoint is called, THEN the TrendSpark System SHALL provide currently relevant trends for the Indian market
